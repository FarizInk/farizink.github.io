<script lang="ts">
  // Dark (default) / Light / Auto. Writes data-theme on <html> and remembers the choice in localStorage('theme').
  import Segmented from './Segmented.svelte';
  import Icon from './Icon.svelte';
  type Mode = 'dark' | 'light' | 'system';
  let { value = $bindable<Mode>('dark') }: { value?: Mode } = $props();

  $effect(() => { try { value = (localStorage.getItem('theme') as Mode) || 'dark'; } catch { /* storage blocked */ } });

  function apply(mode: string) {
    const m = mode as Mode;
    const light = m === 'light' || (m === 'system' && matchMedia('(prefers-color-scheme: light)').matches);
    if (light) document.documentElement.dataset.theme = 'light';
    else delete document.documentElement.dataset.theme;
    try { localStorage.setItem('theme', m); } catch { /* storage blocked */ }
  }
</script>

{#snippet moon()}<Icon name="moon" />{/snippet}
{#snippet sun()}<Icon name="sun" />{/snippet}
{#snippet auto()}<Icon name="monitor" />{/snippet}

<Segmented label="Theme" bind:value onchange={apply} options={[{ value: 'dark', label: 'Dark', icon: moon }, { value: 'light', label: 'Light', icon: sun }, { value: 'system', label: 'Auto', icon: auto }]} />
