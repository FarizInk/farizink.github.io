<script lang="ts">
  // Ready-made Tiptap editor in the Fariz style. Requires:
  //   @tiptap/core @tiptap/starter-kit @tiptap/extension-placeholder @tiptap/extension-highlight
  //   @tiptap/extension-task-list @tiptap/extension-task-item @tiptap/extension-link @tiptap/extension-image
  // Already using Tiptap with your own setup? Keep it, and wrap your element with <EditorShell {editor}> + class="fz-prose".
  import { onMount, onDestroy } from 'svelte';
  import { Editor } from '@tiptap/core';
  import StarterKit from '@tiptap/starter-kit';
  import Placeholder from '@tiptap/extension-placeholder';
  import Highlight from '@tiptap/extension-highlight';
  import TaskList from '@tiptap/extension-task-list';
  import TaskItem from '@tiptap/extension-task-item';
  import Link from '@tiptap/extension-link';
  import Image from '@tiptap/extension-image';
  import EditorShell from './EditorShell.svelte';
  import Modal from './Modal.svelte';
  import TextField from './TextField.svelte';
  import Button from './Button.svelte';

  interface Props { content?: string; placeholder?: string; meta?: string; onupdate?: (html: string, editor: Editor) => void }
  let { content = '', placeholder = 'Start writing…', meta, onupdate }: Props = $props();

  let el: HTMLDivElement | undefined = $state();
  let editor: Editor | null = $state(null);
  let ask: 'link' | 'image' | null = $state(null);
  let url = $state('');

  onMount(() => {
    editor = new Editor({
      element: el,
      extensions: [StarterKit, Placeholder.configure({ placeholder }), Highlight, TaskList, TaskItem.configure({ nested: true }), Link.configure({ openOnClick: false }), Image],
      content,
      editorProps: { attributes: { class: 'fz-prose', 'aria-label': 'Note content' } },
      onUpdate: ({ editor: e }) => onupdate?.(e.getHTML(), e)
    });
  });
  onDestroy(() => editor?.destroy());

  function request(kind: 'link' | 'image') {
    url = kind === 'link' ? (editor?.getAttributes('link').href ?? '') : '';
    ask = kind;
  }
  function apply() {
    if (!editor) return;
    const c = editor.chain().focus() as any;
    if (ask === 'link') url ? c.extendMarkRange('link').setLink({ href: url }).run() : c.extendMarkRange('link').unsetLink().run();
    if (ask === 'image' && url) c.setImage({ src: url }).run();
    ask = null;
  }
</script>

<EditorShell {editor} {meta} onrequest={request}>
  <div bind:this={el}></div>
</EditorShell>

<Modal open={ask !== null} title={ask === 'image' ? 'Insert image' : 'Add link'} onclose={() => (ask = null)}>
  <TextField label="URL" mono placeholder="https://" bind:value={url} onkeydown={(e) => e.key === 'Enter' && apply()} />
  {#snippet actions()}<Button variant="secondary" onclick={() => (ask = null)}>Cancel</Button><Button onclick={apply}>{ask === 'image' ? 'Insert' : 'Save link'}</Button>{/snippet}
</Modal>
