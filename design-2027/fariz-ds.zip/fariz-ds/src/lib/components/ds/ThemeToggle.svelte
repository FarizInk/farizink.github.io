<script lang="ts">
  // Dark is the default theme. Light = <html data-theme="light">, remembered in localStorage.
  // To avoid a flash of the wrong theme, add the snippet from README.md ("No-flash theme script") to index.html <head>.
  import IconButton from './IconButton.svelte';
  let light = $state(false);
  $effect(() => { light = document.documentElement.dataset.theme === 'light'; });

  function toggle() {
    light = !light;
    if (light) document.documentElement.dataset.theme = 'light';
    else delete document.documentElement.dataset.theme;
    try { localStorage.setItem('theme', light ? 'light' : 'dark'); } catch { /* storage blocked */ }
  }
</script>

<IconButton label={light ? 'Switch to dark mode' : 'Switch to light mode'} onclick={toggle}>
  {#if light}
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" /></svg>
  {:else}
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg>
  {/if}
</IconButton>
