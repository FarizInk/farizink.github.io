<script lang="ts">
  // Showcase of every Fariz component — mount at /ds-preview while implementing, remove before release.
  import {
    BentoGrid, BentoCard, Button, IconButton, CopyChip, Tag, NowPlaying, PageHeader, SearchField,
    FilterTabs, ToolCard, NoteCard, StatTile, ServiceTile, EmptyState, ThemeSwitch, Sidebar, Modal, Segmented,
    TextField, Textarea, Select, MultiSelect, Checkbox, Switch, RadioGroup, Slider, FileDrop, Skeleton
  } from './index';
  import NoteEditor from './NoteEditor.svelte';
  let q = $state('');
  let cat = $state('all');
  let menu = $state(false);
  let modal = $state(false);
  let unit = $state('km');
  let labels = $state(['dev', 'homelab']);
  let len = $state(16);
  let style = $state('strong');
  let indent = $state('2');
  let period = $state('month');
</script>

{#snippet brace()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H7a2 2 0 0 0-2 2v4l-2 3 2 3v4a2 2 0 0 0 2 2h1M16 3h1a2 2 0 0 1 2 2v4l2 3-2 3v4a2 2 0 0 1-2 2h-1" /></svg>{/snippet}
{#snippet key()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4" /><path d="M11 12l9-9M17 6l3 3" /></svg>{/snippet}
{#snippet clock()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>{/snippet}
{#snippet burger()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h10" /></svg>{/snippet}
{#snippet home()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11l8-7 8 7" /><path d="M6 10v10h12V10" /></svg>{/snippet}
{#snippet wrench()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 6a4 4 0 0 0-5 5l-5 5 3 3 5-5a4 4 0 0 0 5-5l-3 3-3-3z" /></svg>{/snippet}
{#snippet note()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l4 4v14H6z" /><path d="M9 12h6M9 16h6" /></svg>{/snippet}
{#snippet wallet()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16v12H4z" /><path d="M4 11h16M16 15h2" /></svg>{/snippet}
{#snippet folder()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h6l2 2h8v10H4z" /></svg>{/snippet}
{#snippet arrow()}<svg viewBox="0 0 24 24" class="size-[18px]" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14" /><path d="M13 6l6 6-6 6" /></svg>{/snippet}
{#snippet music()}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l11-2v13" /><circle cx="6" cy="18" r="3" /><circle cx="17" cy="16" r="3" /></svg>{/snippet}

<main class="mx-auto flex max-w-[1120px] flex-col gap-12 px-4 py-16 md:px-6">
  <div class="flex items-center justify-end gap-3">
    <Button variant="secondary" onclick={() => (modal = true)}>Open modal</Button>
    <IconButton label="Open menu" onclick={() => (menu = true)}>{@render burger()}</IconButton>
  </div>

  <section class="flex flex-col gap-4">
    <h2 class="text-label text-ink-muted">Home · bento</h2>
    <BentoGrid>
      <BentoCard tone="accent" colSpan={2} rowSpan={2} size="lg" label="Hi, I'm">
        <span class="text-display-xl">Fariz</span>
        <p class="text-body-lg m-0">Software engineer based in Sidoarjo. Backend, mostly — plus a lot of <em class="not-italic font-semibold">gabut</em> projects.</p>
        <div class="mt-auto flex flex-wrap items-center gap-3">
          <CopyChip value="me@fariz.dev" />
          <IconButton label="Spotify" href="#">{@render music()}</IconButton>
        </div>
      </BentoCard>
      <BentoCard tone="deep" label="Stack">
        <div class="flex flex-wrap gap-2"><Tag>go</Tag><Tag>typescript</Tag><Tag>svelte</Tag></div>
      </BentoCard>
      <BentoCard tone="lime" label="Tools" title="34 utilities" href="#" />
      <NowPlaying isPlaying title="Track title goes here" artist="Artist name" progress={74} duration={212} />
    </BentoGrid>
  </section>

  <section class="flex flex-col gap-6">
    <h2 class="text-label text-ink-muted">Tools · index</h2>
    <PageHeader align="center" badge="34 TOOLS" title="Developer" highlight="Tools" subtitle="Essential utilities for developers, designers, and creators. Fast, free, and private." />
    <SearchField bind:value={q} placeholder="Search tools…" shortcut="Ctrl ⇧ F" />
    <FilterTabs bind:value={cat} items={[{ id: 'all', label: 'All', count: 34 }, { id: 'text-data', label: 'Text & Data', count: 8 }, { id: 'generators', label: 'Generators', count: 7 }, { id: 'web-dev', label: 'Web Dev', count: 6 }, { id: 'utilities', label: 'Utilities', count: 13 }]} />
    <div class="grid gap-4 md:grid-cols-3">
      <ToolCard name="JSON Parser" description="Format, validate and minify JSON" tone="lilac" icon={brace} features={['Validate', 'Format', 'Minify', 'Sort keys']} href="#" />
      <ToolCard name="JWT Decoder" description="Inspect header and payload" tone="deep" icon={key} features={['Header', 'Payload', 'Expiry']} href="#" />
      <ToolCard name="Pomodoro Timer" description="Focused work sessions with breaks" tone="lime" icon={clock} features={['Custom durations', 'Alerts']} href="#" />
    </div>
  </section>

  <section class="flex flex-col gap-4">
    <h2 class="text-label text-ink-muted">Notes · Finance · Services</h2>
    <div class="grid gap-4 md:grid-cols-2">
      <NoteCard pinned title="Homelab setup log" excerpt="Reverse proxy, storage and backups for the home server, step by step." labels={['Homelab']} date="Oct 12, 2026" href="#" />
      <NoteCard title="Svelte 5 runes notes" excerpt="What changes when migrating stores to runes." labels={['Dev', 'Svelte']} date="Sep 30, 2026" attachments={2} href="#" />
    </div>
    <div class="grid gap-4 md:grid-cols-3">
      <StatTile label="Balance" value="Rp 12.450.000" caption="All accounts" tone="deep" />
      <StatTile label="Income" value="Rp 8.200.000" delta={{ direction: 'up', text: '12% vs last month' }} />
      <StatTile label="Spending" value="Rp 3.100.000" delta={{ direction: 'down', text: '4% vs last month' }} />
    </div>
    <div class="grid gap-3 md:grid-cols-2">
      <ServiceTile name="Immich" description="Photo & video backup" href="#" tone="lilac" status="up" />
      <ServiceTile name="9Router" description="Network router management" href="#" tone="violet" status="down" />
    </div>
  </section>

  <section class="flex flex-col gap-6">
    <h2 class="text-label text-ink-muted">Forms</h2>
    <div class="grid gap-6 md:grid-cols-2">
      <div class="flex flex-col gap-5 rounded-lg bg-card p-6">
        <TextField label="Title" placeholder="Untitled note" value="Homelab setup log" />
        <TextField label="Website" optional prefix="https://" placeholder="fariz.dev" />
        <TextField label="Share code" mono value="x9-??" error="Codes use letters and numbers only." />
        <Select label="Convert from" bind:value={unit} options={[{ value: 'm', label: 'Meter', hint: 'm' }, { value: 'km', label: 'Kilometer', hint: 'km' }, { value: 'mi', label: 'Mile', hint: 'mi' }]} />
        <MultiSelect label="Labels" bind:value={labels} options={[{ value: 'dev', label: 'Dev', hint: '12' }, { value: 'homelab', label: 'Homelab', hint: '4' }, { value: 'yapping', label: 'Yapping', hint: '31' }]} />
        <Textarea label="Description" placeholder="What is this about?" hint="Plain text, 280 characters max." />
      </div>
      <div class="flex flex-col gap-5 rounded-lg bg-card p-6">
        <Slider label="Password length" min={4} max={64} bind:value={len} marks={['4', '32', '64']} />
        <div class="grid grid-cols-2 gap-3">
          <Checkbox label="Uppercase (A–Z)" checked /><Checkbox label="Lowercase (a–z)" checked />
          <Checkbox label="Numbers (0–9)" checked /><Checkbox label="Symbols (!@#$%)" />
        </div>
        <Switch label="Session alerts" description="Notify when a Pomodoro ends" checked />
        <RadioGroup label="Password style" variant="cards" bind:value={style} options={[{ value: 'strong', label: 'Strong', description: '16+ chars' }, { value: 'memorable', label: 'Memorable', description: 'Words' }, { value: 'pin', label: 'PIN', description: 'Digits' }]} />
        <RadioGroup label="Indentation" bind:value={indent} options={[{ value: '2', label: '2 spaces' }, { value: '4', label: '4 spaces' }, { value: 'tab', label: 'Tab' }]} />
        <Segmented label="Period" bind:value={period} options={[{ value: 'week', label: 'Week' }, { value: 'month', label: 'Month' }, { value: 'year', label: 'Year' }]} />
      </div>
    </div>
    <FileDrop multiple files={[{ name: 'homelab-diagram.png', meta: '1.8 MB · uploading 64%', progress: 64 }, { name: 'backup-config.yaml', meta: '4 KB · fariz.dev/files/k3x9', onremove: () => {} }]} />
    <NoteEditor meta="Saved · 42 words" content={'<h2>Homelab setup log</h2><p>Reverse proxy first, then <strong>storage</strong> and <mark>backups</mark>. Config lives in <code>/srv/stack</code>.</p><ul><li><p>Caddy in front of every service</p></li><li><p>RustFS for object storage</p></li></ul><ul data-type="taskList"><li data-type="taskItem" data-checked="true"><p>Install Immich</p></li><li data-type="taskItem" data-checked="false"><p>Set up Uptime alerts</p></li></ul><blockquote><p>Back up before every upgrade.</p></blockquote><pre><code>docker compose up -d</code></pre>'} />
  </section>

  <section class="flex flex-col gap-4">
    <h2 class="text-label text-ink-muted">Actions · Feedback</h2>
    <div class="flex flex-wrap items-center gap-3">
      <Button iconRight={arrow}>Browse tools</Button><Button>Upload file</Button><Button variant="secondary">Load sample</Button><Button variant="ghost">Clear</Button><Button size="sm">Save</Button><Button disabled>Disabled</Button>
    </div>
    <div class="grid gap-4 md:grid-cols-2">
      <BentoCard label="Notes · loading"><Skeleton height={22} width="70%" /><Skeleton variant="text" lines={3} /></BentoCard>
      <BentoCard tone="void" label="Now playing · loading"><div class="flex items-center gap-4"><Skeleton width={64} height={64} /><div class="flex-1"><Skeleton variant="text" lines={2} /></div></div></BentoCard>
    </div>
    <EmptyState code="404" title="Page not found" text="This page vanished into the digital void. Head home or try one of the tools.">
      {#snippet actions()}<Button href="#">Back to home</Button><Button variant="secondary" href="#">Browse tools</Button>{/snippet}
    </EmptyState>
  </section>
</main>

<Sidebar bind:open={menu} activeId="tools" groups={[
  { label: 'Explore', items: [{ id: 'home', label: 'Home', href: '#', icon: home }, { id: 'tools', label: 'Tools', hint: '34 developer utilities', href: '#', icon: wrench, badge: 34 }] },
  { label: 'Personal', items: [{ id: 'notes', label: 'Notes', href: '#', icon: note, meta: '59' }, { id: 'finance', label: 'Finance', href: '#', icon: wallet, locked: true }, { id: 'files', label: 'Temp share', href: '#', icon: folder }] }
]}>
  <NowPlaying isPlaying title="Track title goes here" artist="Artist name" progress={74} duration={212} />
  <ThemeSwitch />
</Sidebar>

<Modal bind:open={modal} title="Share this note" description="Anyone with the link can read it until it expires.">
  <Select label="Expires after" value="24h" options={[{ value: '1h', label: '1 hour' }, { value: '24h', label: '24 hours' }, { value: '7d', label: '7 days' }]} />
  {#snippet actions()}<Button variant="secondary" onclick={() => (modal = false)}>Cancel</Button><Button onclick={() => (modal = false)}>Create link</Button>{/snippet}
</Modal>
