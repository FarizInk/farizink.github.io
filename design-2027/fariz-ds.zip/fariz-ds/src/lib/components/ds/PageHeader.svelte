<script lang="ts">
  import type { Snippet } from 'svelte';
  interface Props {
    title: string;
    /** Last word, rendered in accent-text (replaces the old gradient text). */
    highlight?: string;
    subtitle?: string;
    badge?: string | Snippet;
    align?: 'start' | 'center';
  }
  let { title, highlight, subtitle, badge, align = 'start' }: Props = $props();
</script>

<header class="flex flex-col gap-3 px-6 py-8 {align === 'center' ? 'items-center text-center' : 'items-start'}">
  {#if badge}
    <span class="inline-flex h-7 items-center gap-1.5 rounded-pill bg-tile-violet px-3 font-mono text-xs font-medium tracking-wide text-ink-on-dark">
      {#if typeof badge === 'string'}{badge}{:else}{@render badge()}{/if}
    </span>
  {/if}
  <h1 class="text-display m-0">{title}{#if highlight}{' '}<span class="text-accent-text">{highlight}</span>{/if}</h1>
  {#if subtitle}<p class="text-body-lg m-0 max-w-[560px] text-ink-muted">{subtitle}</p>{/if}
</header>
