# Fariz DS — paket untuk repo fariz.dev

Svelte 5 (runes) + Tailwind CSS v4 + Tiptap. Sudah dicek: svelte-check 0 error / 0 warning, vite build berhasil, dirender di dark & light.

## Isi
- `src/styles/fariz-tokens.css` — token warna/radius/font (dark default, light via `data-theme="light"`), utility tipografi.
- `src/styles/fariz-components.css` — gaya flat untuk Sidebar, Modal, form, dan konten editor (`.fz-prose`).
- `src/lib/components/ds/` — semua komponen + `index.ts`, `DsPreview.svelte` (halaman showcase).
- `DESIGN_SYSTEM.md` — panduan untuk Claude Code (taruh di root repo).

### Komponen
Layout & konten: BentoGrid (dengan animasi masuk), BentoCard, NowPlaying, PageHeader, ToolCard, NoteCard, StatTile, ServiceTile, Tag, EmptyState
Aksi: Button, IconButton, CopyChip
Navigasi & overlay: **Sidebar**, **Modal**, **ThemeSwitch** (Dark/Light/Auto), Segmented, SearchField, FilterTabs
Form: **TextField, Textarea, Select, MultiSelect, Checkbox, Switch, RadioGroup** (list / kartu), **Slider, FileDrop**, Field
Editor: **EditorShell** (toolbar untuk instance Tiptap apa pun) + **NoteEditor** (editor siap pakai)
Loading: **Skeleton**
Motion: `motion.ts` (`dur()`, `EASE`, `DURATION`, `reduced()`)

## Pasang
1. Salin `src/` ke repo (gabungkan). Tanpa alias `$lib`, import dengan path relatif.
2. Stylesheet utama:
   ```css
   @import "tailwindcss";
   @import "./styles/fariz-tokens.css";
   @import "./styles/fariz-components.css";
   ```
3. `index.html` `<head>`:
   ```html
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Space+Grotesk:wght@400;500;600;700&display=swap">
   <script>try{var t=localStorage.getItem('theme')||'dark';if(t==='light'||(t==='system'&&matchMedia('(prefers-color-scheme: light)').matches))document.documentElement.dataset.theme='light'}catch(e){}</script>
   ```
   Hapus import font Outfit yang lama.
4. Rute sementara `/ds-preview` → `DsPreview.svelte`, cek di dark & light, hapus sebelum rilis.

## Motion
Sudah aktif otomatis di semua komponen. Tidak ada library tambahan; semuanya CSS dan transisi bawaan Svelte.
- **Token:** `duration-instant` 90ms · `duration-fast` 140ms · `duration-base` 200ms · `duration-slow` 240ms · `stagger` 35ms; easing `ease-soft` · `ease-spring` · `ease-smooth` · `ease-exit`. Keduanya tersedia sebagai class Tailwind (`duration-fast ease-spring`).
- **Press:** tombol, chip, dan tab mengecil ke 0.96; kartu ke 0.985; icon button ke 0.9, lalu memantul kembali.
- **Hover:** isi berubah satu tingkat warna, kartu naik 2px dengan pendar, ikon `iconRight` dan ikon menu bergeser 2px.
- **Form:** centang tergambar sendiri, dot radio muncul dengan pop, chip muncul dari 80% dan bergeser rapi saat ada yang dihapus, dropdown turun dari trigger-nya, field error bergoyang sekali.
- **Overlay:** sidebar dan modal masuk dalam 200–240ms dan keluar lebih cepat (140–160ms).
- **Halaman:** tile `BentoGrid` muncul berurutan dengan selisih 35ms, sekali saat dibuka (`enter={false}` untuk mematikan).
- **Reduce motion:** semua animasi CSS dan transisi Svelte (lewat `dur()`) langsung mati.

Untuk elemen custom di halaman, pakai pola yang sama:
```svelte
<button class="transition-[background-color,scale] duration-fast ease-spring active:scale-[.96]">…</button>
<div transition:fade={{ duration: dur(DURATION.base) }}>…</div>
```
Catatan Tailwind v4: `translate`, `scale`, dan `rotate` adalah properti CSS terpisah, jadi tulis `transition-[translate,scale]`, bukan `transition-transform`.

## Tiptap
- **Sudah punya setup Tiptap sendiri?** Pertahankan. Bungkus elemennya dengan `EditorShell` dan beri class `fz-prose`:
  ```svelte
  <EditorShell {editor} meta="Saved" onrequest={(kind) => /* buka Modal untuk URL link/gambar */}>
    <div bind:this={el}></div>
  </EditorShell>
  ```
  dan di `new Editor({...})` tambahkan `editorProps: { attributes: { class: 'fz-prose' } }`.
  Toolbar memanggil `toggleHighlight` / `toggleTaskList` hanya jika ekstensinya terpasang.
- **Mau pakai `NoteEditor`?** Butuh: `@tiptap/core @tiptap/pm @tiptap/starter-kit @tiptap/extension-placeholder @tiptap/extension-highlight @tiptap/extension-task-list @tiptap/extension-task-item @tiptap/extension-link @tiptap/extension-image` — **semua versi yang sama** (diuji dengan 2.27.3; versi campur menyebabkan error build). Di Tiptap v3, StarterKit sudah berisi Link: hapus `Link` dari daftar extensions.

## Sidebar
```svelte
<IconButton label="Open menu" onclick={() => (menu = true)}><Menu /></IconButton>
<Sidebar bind:open={menu} activeId="tools" groups={[
  { label: 'Explore', items: [{ id: 'home', label: 'Home', href: '/', icon: homeIcon }, { id: 'tools', label: 'Tools', href: '/tools', icon: toolsIcon, badge: 34 }] },
  { label: 'Personal', items: [{ id: 'notes', label: 'Notes', href: '/notes', icon: notesIcon, locked: !loggedIn }] }
]}>
  <NowPlaying {...spotify} />
  <ThemeSwitch />
</Sidebar>
```
Sidebar & Modal sudah menangani Esc, klik overlay, focus trap, kunci scroll, dan mengembalikan fokus.
